/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.adpassignment3;

import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
/**
 *
 * @author Warren Jaftha-219005303------------Reading a file
 */
public class ReadCreateStakeholderSer {
  ObjectInputStream read;
FileWriter writer,writer2;

BufferedWriter buffWriter,buffWriter2;
ArrayList<Customer> customer= new ArrayList<Customer>();
ArrayList<Supplier> supplier= new ArrayList<Supplier>();
    ArrayList<String> date= new ArrayList<String>();

//2a----reading the file and seperating the values into two seperate arraylists called customer and supplier.
    public void OpenFile(){
        try{
            read = new ObjectInputStream( new FileInputStream( "stakeholder.ser" ) ); 
            System.out.println("*** ser file created and opened for reading  ***");               
        }
        catch (IOException ioe){
            System.out.println("error opening ser file: " + ioe.getMessage());
            System.exit(1);
        }
    }
public void readFile(){
try{
while(true){
 Object object = read.readObject();
 String cust ="Customer";
 String sup = "Supplier";
 String name = object.getClass().getSimpleName();
 if ( name.equals(cust)){
 customer.add((Customer)object);
 } else if ( name.equals(sup)){
 supplier.add((Supplier)object);
 } else {
 System.out.println("It didn't work");               
               
               
              
               }
           } 
        }
catch (EOFException eofe) {
System.out.println("End of file reached");
        }
catch (ClassNotFoundException ioe) {
System.out.println("Class error reading ser file: "+ ioe);
        }
catch (IOException ioe) {
System.out.println("Error reading ser file: "+ ioe);
        }
        
sortCustomer();
        
    }
    public void readCloseFile(){
try{
read.close( ); 
        }
catch (IOException ioe){            
System.out.println("error closing ser file: " + ioe.getMessage());
System.exit(1);
        }
    }
    //2b------------Sorting customer based on the HolderId
    public void sortCustomer(){
String[] sortHolderID = new String[customer.size()];
String[] sortSuppName= new String[supplier.size()];
ArrayList<Customer> sortNewArray= new ArrayList<Customer>();
ArrayList<Supplier> sortSuppArray= new ArrayList<Supplier>();
int count = customer.size();
int icount = supplier.size();
for (int i = 0; i < count; i++) {
sortHolderID[i] = customer.get(i).getStHolderId();
        }
Arrays.sort(sortHolderID);
        
for (int i = 0; i < count; i++) {
for (int j = 0; j < count; j++) {
if (sortHolderID[i].equals(customer.get(j).getStHolderId())){
sortNewArray.add(customer.get(j));
                }
            }
        }
customer = sortNewArray;
        
/*(3a) sorting the supplier array alphabetically*/        
for(int i= 0; i<icount;i++){
sortSuppName[i]= supplier.get(i).getName();
        }
Arrays.sort(sortSuppName);
for (int i=0; i<icount;i++){
for (int j=0; j< icount;j++){
if(sortSuppName[i].equals(supplier.get(j).getName())){
sortSuppArray.add(supplier.get(j));
                }
                
            }
            
        }
        
supplier= sortSuppArray;
    }
    
  
    //2e-------Writes the values to the CustomerFile.txt
    public void displayCustomersText() throws ParseException{
         
            
          
            
        try{
           //String fD[]=new String[5];
             
            
writer = new FileWriter("customerOutFile.txt");
          
buffWriter = new BufferedWriter(writer);
            
buffWriter.write(String.format("%-10s \n", "====================================== CUSTOMERS =============================================="));
            
buffWriter.write(String.format("%-15s %-15s %-15s %-15s          %-15s\n", "ID","Name","Surname","Date of Birth","              Age"));
             
buffWriter.write(String.format("%-10s \n", "=============================================================================================="));
          /*(2D)Reformatting the date of birth*/
for (int i = 0; i < customer.size(); i++) {
Date date= null;
            
String ChangeDate=customer.get(i).getDateOfBirth();
SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd");
            
date=  dateFormat.parse(ChangeDate);
           
buffWriter.write(String.format("%-15s %-15s %-15s %-15s          %-15s\n", customer.get(i).getStHolderId(), customer.get(i).getFirstName(), customer.get(i).getSurName(),/*(2C)-This function is used to determine the age of the individuals*/date,2021-Integer.valueOf((customer.get(i).getDateOfBirth().substring(0,4)))));
            }
            
            /*2f determining the amount of individuals that can pay rent and those that cannot pay rent*/
int trueCount=0;
int falseCount=0;
Boolean canPayRent=true;
Boolean cantPayRent=false;
for(int i=0;i<customer.size();i++)
if(customer.get(i).getCanRent()==canPayRent)
            {
trueCount=trueCount +1; 
                
                
            }buffWriter.write(String.format("%-15s %-15s \n", "\nNumber of customers who can rent:",trueCount));
            for(int i=0;i<customer.size();i++)
            if(customer.get(i).getCanRent()==cantPayRent)
            {
                falseCount=falseCount +1; 
                
                
            }buffWriter.write(String.format("%-15s %-15s \n", "\nNumber of customers who cannot rent:",falseCount));
           
      
        
        
        
        
          
            
        
            
          
        }
        catch(IOException fnfe )
        {
            System.out.println(fnfe);
            System.exit(1);
        }
        try{
            buffWriter.close( ); 
        }
        catch (IOException ioe){            
            System.out.println("error closing text file: " + ioe.getMessage());
            System.exit(1);
        }
    }
   
public void displaySupplierText(){
        try{
            /*this is responsible for dispplaying the supplier array*/
            
            writer2= new FileWriter("supplierOutFile.txt");
           
            buffWriter2 = new BufferedWriter(writer2);
           
            buffWriter2.write(String.format("%-10s \n", "================================= SUPPLIERS ================================="));
            
            buffWriter2.write(String.format("%-15s %-20s %-15s %-15s\n", "ID","Product Name","Prod Type        ","   Description"));
            
            buffWriter2.write(String.format("%-10s \n", "============================================================================="));
            
            for (int i = 0; i < supplier.size(); i++) {
                buffWriter2.write(String.format("%-15s %-20s %-20s %-15s\n", supplier.get(i).getStHolderId(), supplier.get(i).getName(), supplier.get(i).getProductType(),supplier.get(i).getProductDescription()));
            }
          
        }
        catch(IOException fnfe )
        {
            System.out.println(fnfe);
            System.exit(1);
        }
        try{
            buffWriter2.close( ); 
        }
        catch (IOException ioe){            
            System.out.println("error closing text file: " + ioe.getMessage());
            System.exit(1);
        }
    }
 
    
      
    
public static void main(String args[]) throws ParseException  {
ReadCreateStakeholderSer obj=new ReadCreateStakeholderSer(); 
obj.OpenFile();
obj.readFile();
obj.readCloseFile();
obj.displayCustomersText();
obj.displaySupplierText();

     }    
     
}